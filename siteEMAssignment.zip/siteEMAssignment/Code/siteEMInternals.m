(* ::Package:: *)

(* Put your code for sequencePosteriors, updateMotifPrior, and updatePFMCounts,
   along with any other functions you write to implement them, in this file.
   Don't forget that you can use your implementation of sitePosterior as part of your
   implementation of sequencePosteriors or, if you prefer, you can request a correct
   version from the TAs. *)
sequencePosteriors[inputsequence_,oldMotifPrior_, oldPFM_, backgroundFreqs_]:= 
Module[{Psequencesite,
Pbackground,subsequence,i,j,k,m,W=Length[oldPFM],L=Length[inputsequence],posterior},
posterior=Range[L-W+1];
For[i=1,i<=L-W+1,i++,
subsequence=Take[inputsequence,{i,i+W-1}];
Psequencesite=Diagonal[Table[oldPFM[[m]][[subsequence[[j]]]],{m,1,Length[oldPFM]},{j,1,Length[subsequence]}]];
Pbackground=Table[backgroundFreqs[[subsequence[[k]]]],{k,1,Length[subsequence]}];
If[Fold[Times,1,Psequencesite]==0&Fold[Times,1,Pbackground]==0,Pbackground=Pbackground,Pbackground=ReplaceAll[0->1][Pbackground]];
posterior[[i]]=Fold[Times,1,Psequencesite]*oldMotifPrior/
(Fold[Times,1,Psequencesite]*oldMotifPrior+
Fold[Times,1,Pbackground]*(1-oldMotifPrior))];
	posterior	   ]

updateMotifPrior[normalizedPosteriors_]:= 
Module[{i,N=Length[normalizedPosteriors]},
Total[Table[Total[normalizedPosteriors[[i]]]/Length[normalizedPosteriors[[i]]],{i,1,N}]]/N]


updatePFMCounts[motifLength_, input_, normalizedPosteriors_, motifPseudocounts_, erasers_]:= 
Module[{j,k,m,i,erasers1},
If[TrueQ[erasers==False],erasers1=Map[ConstantArray[1, #] &, Map[Length, input]],erasers1=erasers];
Table[
(Total[Table[If[input[[j]][[k]]==i,erasers1[[j]][[k]],0],{j,1,Length[input]},{k,m,m+Length[input[[j]]]-motifLength}]
*normalizedPosteriors,{1,Length[normalizedPosteriors]}]+motifPseudocounts[[i]]),{m,1,motifLength},{i,1,4}]
]

